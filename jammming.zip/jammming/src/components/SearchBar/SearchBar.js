import React from 'react';
import './SearchBar.css';
import Spotify from '../../util/Spotify'

class SearchBar extends React.Component {
  constructor(props) {
    super(props);
    this.state = {term: ''};
    this.handleSearch = this.handleSearch.bind(this);
    this.handleTermChange = this.handleTermChange.bind(this);
  }

  handleTermChange(event) {
    this.setState({term: event.target.value});
  }

  handleSearch(event) {
    Spotify.search(this.state.term);
    event.preventDefault();
  }

  handleEnter(event) {
    if(event.keyCode === 13){
    console.log(this.state.term);
    }
	return false;
  }


  render() {
    return (
      <div className="SearchBar">
        <input id="search" type="text" value={this.state.value} onKeyPress={(event) => this.handleEnter(event)} placeholder="Enter A Song, Album, or Artist" onChange={(event) => this.handleTermChange(event)} />
        <a onClick={(event) => this.handleSearch(event)}>SEARCH</a>
      </div>
    );
  }
}

export default SearchBar;
